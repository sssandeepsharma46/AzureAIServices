﻿using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using Microsoft.SemanticKernel.Connectors.OpenAI;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace dnlb.demo.azureopenai
{
    internal class Program
    {
        public static StringBuilder chatHistory = new StringBuilder();
        static async Task Main(string[] args)
        {
            await PerformChatCompletion();
        }

        private static async Task PerformChatCompletion()
        {
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("User >");
                Console.ResetColor();
                var userInput = Console.ReadLine();
                chatHistory.AppendLine("User :"+userInput);
                ///var response = await ProcessChatCompletion(userInput);
                //var response = await ProcessSemanticKernelChatCompletion(userInput);

                var response = await CreateAgentandPlannerCreateCase(chatHistory.ToString());
                chatHistory.AppendLine(response);
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.Write("Assistant >");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine(response);
                Console.ResetColor();
            }
        }

        static async Task<string> CreateAgentandPlannerCreateCase(string userInput)
        {
            try
            {
                string ApiEndpoint = ConfigurationManager.AppSettings["ApiEndpoint"];
                string ApiKey = ConfigurationManager.AppSettings["ApiKey"];
                string ModelName = ConfigurationManager.AppSettings["ModelName"];//gpt-35-turbo-16k
                                                                                 // Create the kernel
                var builder = Kernel.CreateBuilder();
                // builder.Services.AddLogging(c => c.SetMinimumLevel(LogLevel.Trace).AddDebug());
                builder.AddAzureOpenAIChatCompletion(deploymentName: ModelName,
                endpoint: ApiEndpoint,
                            apiKey: ApiKey);
                builder.Plugins.AddFromType<Plugins.CaseCreatePlanner>();
                builder.Plugins.AddFromType<Plugins.CreateCase>();
                Kernel kernel = builder.Build();

                // Retrieve the chat completion service from the kernel
                IChatCompletionService chatCompletionService = kernel.GetRequiredService<IChatCompletionService>();

                // Create the chat history
                ChatHistory chatMessages = new ChatHistory($"You are a friendly assistant who likes to follow the rules. You will complete required steps and request approval before taking any consequential actions. If the user doesn't provide enough information for you to complete a task, you will keep asking questions until you have enough information to complete the task.");
                //chatMessages.AddSystemMessage("Only execute the intended action if the user confirms the details.");
                chatMessages.AddUserMessage(userInput);
                OpenAIPromptExecutionSettings openAIPromptExecutionSettings = new OpenAIPromptExecutionSettings()
                {
                    ToolCallBehavior = ToolCallBehavior.AutoInvokeKernelFunctions
                };
                var result = await chatCompletionService.GetChatMessageContentAsync(
                    chatMessages,
                    executionSettings: openAIPromptExecutionSettings,
                    kernel: kernel);
                return result.Content;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
    }
}
