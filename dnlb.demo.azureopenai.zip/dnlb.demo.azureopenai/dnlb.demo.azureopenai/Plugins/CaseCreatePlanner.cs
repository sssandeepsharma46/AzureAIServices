﻿using Microsoft.SemanticKernel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dnlb.demo.azureopenai.Plugins
{
    public class CaseCreatePlanner
    {
        [KernelFunction]
        [Description("Returns back the required steps necessary to create case.")]
        [return: Description("The list of steps need to create the case.")]
        public async Task<string> CaseCreatePlannerStepsAsync(
    Kernel kernel,
    [Description("A one line sentence about the topic of the Case.")] string topic,
    [Description("An Email address of the customer.")] string email,
    [Description("A short description about the case")] string description
)
        {
            var steps = new StringBuilder();

            // Prompt user to provide details of the case
            steps.AppendLine($"1. Provide the details of the case:");
            steps.AppendLine($"    - Topic: {topic}");
            steps.AppendLine($"    - Email: {email}");
            steps.AppendLine($"    - Description: {description}");
            steps.AppendLine($"2. Once required information are captured from user, show the capture details to user for confirmation.");
            steps.AppendLine($"3. Always ask for the confirmation of the details are correct by responding with 'Yes' or 'No'.");
            steps.AppendLine($"4. If only user confirms Yes then only create case.");
            var result = await kernel.InvokePromptAsync(steps.ToString(), new KernelArguments() { { "topic", topic }, { "email", email }, { "description", description } });

            // Return the plan back to the agent
            return result.ToString();
        }
    }
}
