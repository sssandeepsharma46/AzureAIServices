﻿using Microsoft.SemanticKernel;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.PowerPlatform.Dataverse.Client;

namespace dnlb.demo.azureopenai.Plugins
{
    public class CreateCase
    {
        [KernelFunction]
        [Description("Create or Report Case")]
        public async Task<string> CreateCaseAsync(
    Kernel kernel,
    [Description("A one line sentence about the topic of the Case.")] string topic,
    [Description("An Email address of the customer.")] string email,
    [Description("A short description about the case")] string description
)
        {
            try
            {
                //Console.WriteLine("Kernel" + kernel.ToString());
                // Add logic to send an email using the recipientEmails, subject, and body
                // For now, we'll just print out a success message to the console
                ServiceClient crmService = InitalizeCRMServiceClient();
                Entity contactRecord = GetContactByEmailId(crmService, email);

                Entity createCase = new Entity("incident");
                createCase["title"] = topic;
                createCase["customerid"] = new EntityReference(contactRecord.LogicalName, contactRecord.Id);
                createCase["description"] = description;
                Guid caseId = crmService.Create(createCase);
                return $"Case has been created with id {caseId}";

            }
            catch (Exception ex)
            {
                return ex.Message;
            }

        }

        private ServiceClient InitalizeCRMServiceClient()
        {

            string appClientId = ConfigurationManager.AppSettings["ClientId"];
            string appClientSecret = ConfigurationManager.AppSettings["ClientSecret"];
            string crmEnvironmentURL = ConfigurationManager.AppSettings["CRMURL"];
            var connectionString = $"Url={crmEnvironmentURL};AuthType=ClientSecret;ClientId={appClientId};ClientSecret={appClientSecret};RequireNewInstance=true";
            return new ServiceClient(connectionString);
        }

        private Entity GetContactByEmailId(ServiceClient crmService, string emailId)
        {
            string fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' savedqueryid='00000000-0000-0000-00aa-000010001003' no-lock='false' distinct='true'>" +
                            "	<entity name='contact'>" +
                            "		<attribute name='entityimage_url'/>" +
                            "		<attribute name='statecode'/>" +
                            "		<attribute name='fullname'/>" +
                            "		<order attribute='fullname' descending='false'/>" +
                            "		<attribute name='parentcustomerid'/>" +
                            "		<attribute name='telephone1'/>" +
                            "		<attribute name='emailaddress1'/>" +
                            "		<attribute name='contactid'/>" +
                            "		<filter type='and'>" +
                            "			<condition attribute='statecode' operator='eq' value='0'/>" +
                            "			<condition attribute='emailaddress1' operator='eq' value='" + emailId + "'/>" +
                            "		</filter>" +
                            "	</entity>" +
                            "</fetch>";

            EntityCollection ecContacts = crmService.RetrieveMultiple(new FetchExpression(fetchXML));
            return ecContacts.Entities.FirstOrDefault();
        }
    }
}
