﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;

namespace dnlb.azureopenai.demo.Plugins
{
    public class DNLBDetails
    {
        [KernelFunction, Description("Get the DNLB Details")]
        public async Task<string> GetDNLBDetails()
        {
            Console.WriteLine("Plugin >The DNLB full form is Dot Net Little Boy.");
            return "The DNLB full form is Dot Net Little Boy.";
        }

        [KernelFunction, Description("Get the DNLB Address")]
        
        public async Task<string> GetDNLBAddress()
        {
            Console.WriteLine("Plugin >The address of DNLB is Asia, India");
            return "The address of DNLB is Asia, India";
        }
        [KernelFunction, Description("Get the company details")]
        public async Task<string> GetDLLBCompanyDetails([Description("The company name")] string company)
        {
            Console.WriteLine($"Plugin > The the company is {company}");
            return $"Plugin > The the company is {company}";
        }
    }
}
