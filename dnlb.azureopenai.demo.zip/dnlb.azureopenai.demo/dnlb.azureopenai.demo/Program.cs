﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using Azure;
using Azure.AI.OpenAI;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using Microsoft.SemanticKernel.Connectors.OpenAI;
namespace dnlb.azureopenai.demo
{
    internal class Program
    {
        static ChatHistory chatHistory = new ChatHistory();
        static async Task Main(string[] args)
        {
            await PerformChatCompletion();
        }

        private static async Task PerformChatCompletion()
        {
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("User >");
                Console.ResetColor();
                var userInput = Console.ReadLine();
                chatHistory.AddUserMessage(userInput);
                ///var response = await ProcessChatCompletion(userInput);
                //var response = await ProcessSemanticKernelChatCompletion(userInput);
                
                var response = await SemanticKernelWithAIPlugin(userInput);
                chatHistory.AddAssistantMessage(response);
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.Write("Assistant >");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine(response);
                Console.ResetColor();
            }
        }

        private static async Task<string> ProcessChatCompletion(string userInput)
        {
            string modelName = ConfigurationSettings.AppSettings["ModelName"];//gpt-35-turbo-16k
            string endPoint = ConfigurationSettings.AppSettings["ApiEndpoint"];
            string key = ConfigurationSettings.AppSettings["ApiKey"];
            var chatCompletionOption = new ChatCompletionsOptions();
            chatCompletionOption.Messages.Add(new ChatRequestUserMessage(userInput));
            chatCompletionOption.DeploymentName = modelName;
            chatCompletionOption.Temperature = 0;

            var openAIClient = new OpenAIClient(new Uri(endPoint), new AzureKeyCredential(key));
            var chatResponse = await openAIClient.GetChatCompletionsAsync(chatCompletionOption);
            return chatResponse.Value.Choices[0].Message.Content;
        }

        private static async Task<string> ProcessSemanticKernelChatCompletion(string userInput)
        {
            try
            {
                string modelName = ConfigurationSettings.AppSettings["ModelName"];//gpt-35-turbo-16k
                string APIendPoint = ConfigurationSettings.AppSettings["ApiEndpoint"];
                string key = ConfigurationSettings.AppSettings["ApiKey"];

                Kernel dnlbKernel = Kernel.CreateBuilder().AddAzureOpenAIChatCompletion(deploymentName: modelName,
                    endpoint: APIendPoint,
                    apiKey: key).Build();

                var kernelChatCompletionService = dnlbKernel.GetRequiredService<IChatCompletionService>();
                var openAIExectionSetting = new OpenAIPromptExecutionSettings()
                {
                    Temperature = 0

                };

                var chatResponse = await kernelChatCompletionService.GetChatMessageContentAsync(userInput, openAIExectionSetting, dnlbKernel);
                return chatResponse.Content;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
           
        }

        private static async Task<string> SemanticKernelWithAIPlugin(string userInput)
        {
            string modelName = ConfigurationSettings.AppSettings["ModelName"];//gpt-35-turbo-16k
            string APIendPoint = ConfigurationSettings.AppSettings["ApiEndpoint"];
            string key = ConfigurationSettings.AppSettings["ApiKey"];

            var builder = Kernel.CreateBuilder().AddAzureOpenAIChatCompletion(deploymentName: modelName,
                    endpoint: APIendPoint,
                    apiKey: key);
            builder.Plugins.AddFromType<Plugins.DNLBDetails>();
            var semanticKernel = builder.Build();

            var chatCompletionService = semanticKernel.GetRequiredService<IChatCompletionService>();
            var promptExecutionSetting = new OpenAIPromptExecutionSettings()
            {
                Temperature = 0,
                ToolCallBehavior = ToolCallBehavior.EnableKernelFunctions
            };

            ChatHistory history = new ChatHistory();
            history.AddUserMessage(userInput);
            var chatResponse = await chatCompletionService.GetChatMessageContentAsync(userInput, executionSettings: promptExecutionSetting, kernel: semanticKernel);
            var functionCalls = ((OpenAIChatMessageContent)chatResponse).GetOpenAIFunctionToolCalls().ToList();
            foreach(var SKFunctionCall in functionCalls)
            {
                if(SKFunctionCall.FunctionName == "GetDNLBDetails")
                {
                    semanticKernel.Plugins.TryGetFunctionAndArguments(SKFunctionCall, out KernelFunction pluginFunction, out KernelArguments arguments);
                    arguments.Add("name", "DnLB");
                    var res = semanticKernel.InvokeAsync(pluginFunction, arguments);
                    return res.Result.ToString();
                }else if(SKFunctionCall.FunctionName == "GetDNLBAddress")
                {
                    semanticKernel.Plugins.TryGetFunctionAndArguments(SKFunctionCall, out KernelFunction pluginFunction, out KernelArguments arguments);
                    arguments.Add("name", "DnLB");
                    var res = semanticKernel.InvokeAsync(pluginFunction, arguments);
                    return res.Result.ToString();
                }
            }

            var result  = await semanticKernel.InvokeAsync("DNLBDetails", "GetDLLBCompanyDetails", new KernelArguments { ["company"] = "DNLB" });
            return result.ToString();

        }
    }
}
